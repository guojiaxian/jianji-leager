// ============================================================
// 简记 · 主逻辑
// ============================================================

// ---------- 启动页 ----------
window.addEventListener('load', function () {
  const splash = document.getElementById('splash');
  if (!splash) return;
  if (sessionStorage.getItem('jianji_splash_shown')) { splash.remove(); return; }
  sessionStorage.setItem('jianji_splash_shown', '1');
  setTimeout(function () {
    splash.classList.add('fade');
    setTimeout(function () { splash.remove(); }, 560);
  }, 1950);
});

// ---------- 全局状态 ----------
let currentPage = 'home';
let currentStatsPeriod = 'day';
let statsDate = new Date();            // 统计锚点日期
let calendarMonth = new Date();        // 日历月份
let billsMonth = new Date();           // 明细页月份
let selectedCategory = null;           // 手动记账选中分类
let selectedSubcategory = null;
let manualFlow = 'expense';            // 手动记账：支出 / 收入
let ocrQueue = [];                     // 多图识别队列 {id, dataUrl, status, result, error}
let ocrCards = [];                     // 弹层中可编辑的识别结果
let ocrSheetOpen = false;              // 弹层是否已打开

// 图表配色（暖色 · 纸墨相容）
// 柔和莫兰迪调色板（分类构成用，低饱和、互异）
const CHART_COLORS = ['#D89A86', '#8FAED1', '#E2BF84', '#BEA6CC', '#85BEAB', '#E0A2B0', '#7EA6CB', '#8FBDB4', '#A7A08F', '#C9B16E'];
// 分类名 → 固定柔和色（保证同分类始终同色、且互有区分）
const CATEGORY_COLORS = {
  '餐饮': '#D89A86', '交通': '#8FAED1', '购物': '#E2BF84', '娱乐': '#BEA6CC',
  '居住': '#85BEAB', '医疗': '#E0A2B0', '教育': '#7EA6CB', '通讯': '#8FBDB4',
  '其他': '#A7A08F',
  '工资': '#7E9E8F', '奖金': '#B7C96E', '兼职': '#93B48A', '理财': '#C9AF6B',
  '红包': '#E08B7E', '退款': '#82A5BF', '其他收入': '#A89B6F'
};
function catColor(name) {
  if (CATEGORY_COLORS[name]) return CATEGORY_COLORS[name];
  // 未知分类：按名称稳定散列到柔和调色板
  let h = 0;
  for (let k = 0; k < name.length; k++) h = (h * 31 + name.charCodeAt(k)) >>> 0;
  return CHART_COLORS[h % CHART_COLORS.length];
}

// 星期与时段
const WEEK_CN = ['日', '一', '二', '三', '四', '五', '六'];
const TIME_SEGMENTS = [
  { name: '深夜 0-4时', from: 0, to: 4 },
  { name: '清晨 4-8时', from: 4, to: 8 },
  { name: '上午 8-12时', from: 8, to: 12 },
  { name: '午后 12-16时', from: 12, to: 16 },
  { name: '傍晚 16-20时', from: 16, to: 20 },
  { name: '夜晚 20-24时', from: 20, to: 24 }
];

// ---------- 工具 ----------
function getCategoryIcon(name) {
  const cat = getCategories().find(c => c.name === name)
    || getIncomeCategories().find(c => c.name === name);
  return cat ? cat.icon : '📌';
}

function isIncome(t) {
  return t.flow === 'income';
}

function sumBy(list, fn) {
  return list.reduce((s, x) => s + (fn ? fn(x) : x), 0);
}

function fmtMoney(n) {
  return Number(n || 0).toFixed(2);
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 2200);
}

// ---------- 导航 ----------
function navigateTo(page, subTab) {
  currentPage = page;
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(`page-${page}`).classList.add('active');

  document.querySelectorAll('.tab-item').forEach(n => n.classList.remove('active'));
  const tab = document.querySelector(`.tab-item[data-page="${page}"]`);
  if (tab) tab.classList.add('active');
  document.getElementById('tabAddBtn').classList.toggle('active', page === 'add');

  document.getElementById(`page-${page}`).scrollTop = 0;

  if (page === 'home') renderHome();
  else if (page === 'add') switchAddTab(subTab === 'auto' ? 'auto' : 'manual');
  else if (page === 'stats') renderStats();
  else if (page === 'bills') renderBills();
  else if (page === 'settings') renderSettings();
}

// ============================================================
// 首页
// ============================================================
function renderHome() {
  const today = getTodayStr();
  const todayTotal = sumBy(getTransactionsByDate(today).filter(t => !isIncome(t)), t => t.amount);
  const weekTotal = sumBy(getTransactionsByWeek(today).filter(t => !isIncome(t)), t => t.amount);
  const now = new Date();
  const monthTx = getTransactionsByMonth(now.getFullYear(), now.getMonth() + 1);
  const monthTotal = sumBy(monthTx.filter(t => !isIncome(t)), t => t.amount);
  const monthIncome = sumBy(monthTx.filter(isIncome), t => t.amount);

  document.getElementById('todayAmount').textContent = fmtMoney(todayTotal);
  document.getElementById('weekAmount').textContent = '¥' + Math.round(weekTotal);
  document.getElementById('monthAmount').textContent = '¥' + Math.round(monthTotal);
  document.getElementById('monthIncome').textContent = '¥' + Math.round(monthIncome);

  renderHomeFlow();
}

// ============================================================
// 账单流水（首页）：按日期/时间排序分组 + 无限下滑加载
// ============================================================
let homeFlowAll = [];      // 排序后的全量流水
let homeFlowIndex = 0;     // 已渲染到的下标
let homeFlowLastDate = null;
let homeFlowScrollEl = null;
let homeFlowScrollFn = null;
const HOME_FLOW_STEP = 15;
const HOME_FLOW_ROOT_OFFSET = 200;

function sortTxByDateTime(list) {
  return [...list].sort((a, b) => {
    const d = (b.date || '').localeCompare(a.date || '');
    if (d !== 0) return d;
    const t = (b.time || '').localeCompare(a.time || '');
    if (t !== 0) return t;
    return (b.createdAt || 0) - (a.createdAt || 0);
  });
}

function renderHomeFlow() {
  const listEl = document.getElementById('homeFlow');
  const endEl = document.getElementById('homeFlowEnd');
  detachHomeFlowScroll();

  homeFlowLastDate = null;
  homeFlowAll = sortTxByDateTime(getTransactions());
  listEl.innerHTML = '';
  if (!homeFlowAll.length) {
    endEl.textContent = '暂无流水';
    endEl.style.display = 'block';
    return;
  }
  endEl.textContent = '';

  homeFlowIndex = 0;
  appendHomeFlow();
  observeHomeFlow();
  fillUntilScrollable();
}

function flowHeadHtml(date, items) {
  const exp = sumBy(items.filter(t => !isIncome(t)), t => t.amount);
  const inc = sumBy(items.filter(isIncome), t => t.amount);
  const d = new Date(date + 'T00:00:00');
  return `<div class="day-head"><span>${d.getMonth() + 1}月${d.getDate()}日 · 周${WEEK_CN[d.getDay()]}</span>` +
    `<span class="d-amt">${inc > 0 ? `<em class="income-val">+¥${fmtMoney(inc)}</em> · ` : ''}¥${fmtMoney(exp)}</span></div>`;
}

function appendHomeFlow() {
  const listEl = document.getElementById('homeFlow');
  const endEl = document.getElementById('homeFlowEnd');
  const batch = homeFlowAll.slice(homeFlowIndex, homeFlowIndex + HOME_FLOW_STEP);
  homeFlowIndex += batch.length;

  // homeFlowAll 已按日期降序，批次内按日期分组
  const groups = {};
  batch.forEach(t => { (groups[t.date] = groups[t.date] || []).push(t); });

  Object.keys(groups).sort().reverse().forEach(date => {
    const items = groups[date];
    if (date === homeFlowLastDate && homeFlowLastDate) {
      const panels = listEl.querySelectorAll('.day-panel');
      if (panels.length) panels[panels.length - 1].insertAdjacentHTML('beforeend', items.map(txRowHtml).join(''));
    } else {
      listEl.insertAdjacentHTML('beforeend',
        `<div class="day-group">${flowHeadHtml(date, items)}<div class="day-panel">${items.map(txRowHtml).join('')}</div></div>`);
      homeFlowLastDate = date;
    }
  });

  if (homeFlowIndex >= homeFlowAll.length) {
    endEl.textContent = '—— 已到底 ——';
    endEl.style.display = 'block';
    detachHomeFlowScroll();
  } else {
    endEl.textContent = '';
    endEl.style.display = 'block';
  }
}

// 滚动容器接近底部时加载下一批
function observeHomeFlow() {
  detachHomeFlowScroll();
  homeFlowScrollEl = document.getElementById('page-home');
  homeFlowScrollFn = onHomeFlowScroll;
  homeFlowScrollEl.addEventListener('scroll', homeFlowScrollFn, { passive: true });
}

// 首屏内容不足以产生滚动时，自动继续填充直到可滚动
function fillUntilScrollable() {
  const page = document.getElementById('page-home');
  let guard = 0;
  while (homeFlowIndex < homeFlowAll.length && page.scrollHeight <= page.clientHeight && guard < 50) {
    appendHomeFlow();
    guard++;
  }
}

function onHomeFlowScroll() {
  if (homeFlowIndex >= homeFlowAll.length) { detachHomeFlowScroll(); return; }
  const page = document.getElementById('page-home');
  if (page.scrollTop + page.clientHeight >= page.scrollHeight - HOME_FLOW_ROOT_OFFSET) {
    appendHomeFlow();
  }
}

function detachHomeFlowScroll() {
  if (homeFlowScrollEl && homeFlowScrollFn) {
    homeFlowScrollEl.removeEventListener('scroll', homeFlowScrollFn);
  }
  homeFlowScrollEl = null;
  homeFlowScrollFn = null;
}

function txRowHtml(t) {
  const icon = getCategoryIcon(t.category);
  const title = t.subcategory || t.category;
  const sub = t.note || (t.items && t.items.length ? t.items.join('、') : t.category);
  const income = isIncome(t);
  return `
    <div class="tx-row">
      <div class="tx-ico">${icon}</div>
      <div class="tx-main">
        <div class="tx-title">${title}</div>
        <div class="tx-sub">${t.platform ? t.platform + ' · ' : ''}${t.category} · ${sub}</div>
      </div>
      <div class="tx-right">
        <div class="tx-amount fig ${income ? 'income-val' : ''}">${income ? '+' : ''}¥${fmtMoney(t.amount)}</div>
        <div class="tx-time">${t.time || ''}</div>
      </div>
    </div>`;
}

function renderTransactionList(containerId, transactions) {
  const el = document.getElementById(containerId);
  if (!transactions.length) {
    el.innerHTML = '<div class="empty-state">还没有账目</div>';
    return;
  }
  el.innerHTML = transactions.map(txRowHtml).join('');
}

// ============================================================
// 记账页
// ============================================================
function switchAddTab(tab) {
  document.querySelectorAll('#addSeg button').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
  document.querySelectorAll('#page-add .tab-content').forEach(c => c.classList.remove('active'));
  document.getElementById(`tab-${tab}`).classList.add('active');
  document.getElementById('addSegInd').style.transform = tab === 'auto' ? 'translateX(100%)' : 'translateX(0)';

  if (tab === 'manual') initManualForm();
  else initOcrForm();
}

// ---------- 手动 ----------
function initManualForm(flow) {
  if (flow) switchManualFlow(flow, true);
  document.getElementById('manualDate').value = getTodayStr();
  document.getElementById('manualTime').value = getTimeStr();
  document.getElementById('manualAmount').value = '';
  document.getElementById('manualNote').value = '';
  selectedCategory = null;
  selectedSubcategory = null;
  document.getElementById('subcategorySection').hidden = true;

  renderCategoryGrid('categoryGrid', 'manual');
}

function switchManualFlow(flow, silent) {
  manualFlow = flow === 'income' ? 'income' : 'expense';
  document.querySelectorAll('#flowToggle button').forEach(b => {
    b.classList.toggle('active', b.dataset.flow === manualFlow);
  });
  document.getElementById('manualAmountLabel').textContent = manualFlow === 'income' ? '收入金额' : '金额';
  document.getElementById('manualSubmitBtn').textContent = manualFlow === 'income' ? '记 收 入' : '记 入';
  selectedCategory = null;
  selectedSubcategory = null;
  document.getElementById('subcategorySection').hidden = true;
  renderCategoryGrid('categoryGrid', 'manual');
}

function goExpenseEntry() {
  navigateTo('add');
  switchManualFlow('expense');
}

function goIncomeEntry() {
  navigateTo('add');
  switchManualFlow('income');
}

// 首页"拍照记账"：进入拍照页并直接弹出图片选择
function startPhotoAccounting() {
  navigateTo('add', 'auto');
  document.getElementById('ocrFileInput').click();
}

function renderCategoryGrid(containerId, ctx) {
  const cats = manualFlow === 'income' ? getIncomeCategories() : getCategories();
  const el = document.getElementById(containerId);
  el.innerHTML = cats.map(c => `
    <button class="cat-chip" data-cat="${c.name}" onclick="pickCategory('${c.name}','${ctx}')">
      <span class="cc-ico">${c.icon}</span>
      <span class="cc-name">${c.name}</span>
    </button>`).join('');
}

function markCatSelection(containerId, name) {
  document.querySelectorAll(`#${containerId} .cat-chip`).forEach(b => {
    b.classList.toggle('selected', b.dataset.cat === name);
  });
}

function pickCategory(name, ctx) {
  selectedCategory = name;
  selectedSubcategory = null;
  markCatSelection('categoryGrid', name);
  renderSubcategories(name);
}

function renderSubcategories(catName) {
  const cat = getCategories().find(c => c.name === catName);
  const sec = document.getElementById('subcategorySection');
  if (!cat || !cat.subcategories.length) { sec.hidden = true; return; }
  sec.hidden = false;
  document.getElementById('subcategoryList').innerHTML = cat.subcategories.map(s => `
    <button class="chip" onclick="pickSubcategory('${s}')">${s}</button>`).join('');
}

function pickSubcategory(name) {
  selectedSubcategory = name;
  document.querySelectorAll('#subcategoryList .chip').forEach(b => {
    b.classList.toggle('selected', b.textContent === name);
  });
}

function saveManualEntry() {
  const amount = parseFloat(document.getElementById('manualAmount').value);
  if (!amount || amount <= 0) return showToast('请输入金额');
  if (!selectedCategory) return showToast('请选择分类');

  addTransaction({
    amount,
    category: selectedCategory,
    subcategory: selectedSubcategory || '',
    note: document.getElementById('manualNote').value.trim(),
    date: document.getElementById('manualDate').value,
    time: document.getElementById('manualTime').value,
    type: 'manual',
    flow: manualFlow
  });

  showToast(manualFlow === 'income' ? '收入已记入' : '已记入账本');
  initManualForm(manualFlow);
  renderHome();
}

// ---------- 拍照（多图自动识别流程）----------
function initOcrForm() {
  ocrQueue = [];
  ocrCards = [];
  ocrSheetOpen = false;
  document.getElementById('uploadEmpty').hidden = false;
  document.getElementById('uploadPreviewWrap').hidden = true;
  document.getElementById('scanStatus').textContent = '';
  document.getElementById('ocrFileInput').value = '';
  closeOcrSheet();
}

function handleOcrFile(e) {
  const files = Array.from(e.target.files || []);
  e.target.value = ''; // 允许重复选择同一文件
  if (!files.length) return;

  const readers = files.map(f => new Promise(res => {
    const r = new FileReader();
    r.onload = ev => res(ev.target.result);
    r.readAsDataURL(f);
  }));

  Promise.all(readers).then(datas => {
    datas.forEach(dataUrl => {
      ocrQueue.push({
        id: 'q' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
        dataUrl, status: 'pending', results: null, error: ''
      });
    });
    document.getElementById('uploadEmpty').hidden = true;
    document.getElementById('uploadPreviewWrap').hidden = false;
    renderThumbGrid();
    updateScanStatus();
    ocrQueue.filter(q => q.status === 'pending').forEach(analyzeOne); // 并行识别
  });
}

async function analyzeOne(item) {
  item.status = 'running';
  renderThumbGrid();
  updateScanStatus();
  try {
    // ocrRecognize 返回订单数组（单笔则为长度1）
    item.results = await ocrRecognize(item.dataUrl);
    item.status = 'done';
  } catch (err) {
    item.status = 'error';
    item.error = err.message;
  }
  renderThumbGrid();
  updateScanStatus();
  maybeOpenSheet();
}

function renderThumbGrid() {
  const el = document.getElementById('thumbGrid');
  el.innerHTML = ocrQueue.map((q, i) => {
    const badge = q.status === 'running' ? '<span class="tb-badge running"></span>'
      : q.status === 'done' ? '<span class="tb-badge done">✓</span>'
      : q.status === 'error' ? '<span class="tb-badge error">✕</span>' : '';
    const tip = q.status === 'error' ? ' title="识别失败，点击重试"' : '';
    const click = q.status === 'error' ? ` onclick="retryOcrItem(${i})"` : '';
    return `<div class="thumb ${q.status}"${tip}${click}><img src="${q.dataUrl}" alt="">${badge}</div>`;
  }).join('');
}

function retryOcrItem(i) {
  const item = ocrQueue[i];
  if (!item || item.status !== 'error') return;
  analyzeOne(item);
}

function updateScanStatus() {
  const el = document.getElementById('scanStatus');
  const running = ocrQueue.filter(q => q.status === 'running' || q.status === 'pending').length;
  const done = ocrQueue.filter(q => q.status === 'done').length;
  const failed = ocrQueue.filter(q => q.status === 'error').length;
  if (running) el.textContent = `正在识别 ${done + failed}/${ocrQueue.length} …`;
  else if (failed && !done) el.textContent = '全部识别失败 · 点击缩略图重试';
  else if (failed) el.textContent = `识别完成 · ${failed} 张失败可点缩略图重试`;
  else el.textContent = `识别完成 · 共 ${done} 张`;
}

function maybeOpenSheet() {
  if (ocrQueue.some(q => q.status === 'pending' || q.status === 'running')) return; // 还有在识别的
  const okItems = ocrQueue.filter(q => q.status === 'done');
  if (!okItems.length) return;
  openOcrSheet(okItems);
}

// ---------- 结果弹层（多图 × 多笔订单展开）----------
function openOcrSheet(items) {
  const platformMap = { '微信': '餐饮', '支付宝': '购物', '淘宝': '购物', '京东': '购物', '拼多多': '购物', '纸质小票': '餐饮' };
  const catNames = getCategories().map(c => c.name);

  ocrCards = [];
  items.forEach(q => {
    // 每张图可能识别出多笔订单，逐笔展开为独立卡片
    (Array.isArray(q.results) ? q.results : []).forEach(r => {
      const suggested = [r.category, platformMap[r.platform]].find(c => c && catNames.includes(c)) || '其他';
      ocrCards.push({
        thumb: q.dataUrl,
        platform: r.platform || '',
        amount: r.amount ?? '',
        date: r.date || getTodayStr(),
        time: r.time || getTimeStr(),
        category: suggested,
        items: (r.items || []).filter(Boolean),
        merchant: r.merchant || ''
      });
    });
  });

  renderOcrCards();
  updateOcrSummary();
  ocrSheetOpen = true;
  document.getElementById('ocrSheetMask').classList.add('show');
  document.getElementById('ocrSheet').classList.add('show');
}

function renderOcrCards() {
  const el = document.getElementById('ocrCards');
  const cats = getCategories();
  el.innerHTML = ocrCards.map((c, i) => `
    <div class="ocr-card">
      <div class="oc-head">
        <img class="oc-thumb" src="${c.thumb}" alt="">
        <span class="order-type-tag">${c.platform || '未识别'}</span>
        <button class="oc-del" onclick="removeOcrCard(${i})" title="放弃这一笔">✕</button>
      </div>
      <div class="oc-body">
        <div class="amount-display fig oc-amount">
          <span class="yen">¥</span>
          <input type="number" step="0.01" min="0" inputmode="decimal" value="${c.amount}"
                 oninput="updateOcrCard(${i},'amount',this.value)">
        </div>
        <div class="form-row">
          <div class="form-cell">
            <label>日期</label>
            <input type="date" value="${c.date}" oninput="updateOcrCard(${i},'date',this.value)">
          </div>
          <div class="form-cell">
            <label>时间</label>
            <input type="time" value="${c.time}" oninput="updateOcrCard(${i},'time',this.value)">
          </div>
        </div>
        <div class="oc-cats">
          ${cats.map(cat => `
            <button class="chip ${cat.name === c.category ? 'selected' : ''}"
                    onclick="pickOcrCardCat(${i},'${cat.name}')">${cat.icon} ${cat.name}</button>`).join('')}
        </div>
        <div class="tag-list oc-items">
          ${c.items.length ? c.items.map(it => `<span class="tag">${it}</span>`).join('') : '<span class="muted">未识别到物品</span>'}
        </div>
        <input type="text" class="plain-input" maxlength="50" placeholder="备注（默认商家名）" value="${c.merchant || ''}"
               oninput="updateOcrCard(${i},'merchant',this.value)">
      </div>
    </div>`).join('');
}

function updateOcrCard(i, field, value) {
  if (!ocrCards[i]) return;
  ocrCards[i][field] = value;
  updateOcrSummary();
}

function pickOcrCardCat(i, name) {
  if (!ocrCards[i]) return;
  ocrCards[i].category = name;
  renderOcrCards(); // 重渲染选中态
}

function removeOcrCard(i) {
  ocrCards.splice(i, 1);
  if (!ocrCards.length) { resetOcr(); return; }
  renderOcrCards();
  updateOcrSummary();
}

function updateOcrSummary() {
  const el = document.getElementById('ocrSummary');
  const valid = ocrCards.filter(c => parseFloat(c.amount) > 0);
  const total = valid.reduce((s, c) => s + parseFloat(c.amount), 0);
  el.textContent = `共 ${ocrCards.length} 笔 · 合计 ¥${fmtMoney(total)}`;
  document.getElementById('ocrSaveBtn').textContent = ocrCards.length > 1 ? `全部记入（${ocrCards.length}笔）` : '确认记入';
}

function closeOcrSheet() {
  ocrSheetOpen = false;
  document.getElementById('ocrSheetMask').classList.remove('show');
  document.getElementById('ocrSheet').classList.remove('show');
}

function saveOcrEntries() {
  const valid = ocrCards.filter(c => {
    const amt = parseFloat(c.amount);
    return amt > 0;
  });
  if (!valid.length) return showToast('没有可记入的账目（金额无效）');

  for (const c of valid) {
    addTransaction({
      amount: parseFloat(c.amount),
      category: c.category || '其他',
      subcategory: '',
      note: (c.merchant || '').trim(),
      date: c.date,
      time: c.time,
      type: 'auto',
      platform: c.platform,
      items: c.items || []
    });
  }

  closeOcrSheet();
  initOcrForm();
  renderHome();
  showToast(`已记入 ${valid.length} 笔账目`);
}

function resetOcr() {
  closeOcrSheet();
  initOcrForm();
}

// ============================================================
// 统计页
// ============================================================
function renderStats() {
  loadStatsData();
}

function switchStatsPeriod(period) {
  currentStatsPeriod = period;
  statsDate = new Date();
  document.querySelectorAll('#statsSeg button').forEach(b => {
    b.classList.toggle('active', b.dataset.period === period);
  });
  document.getElementById('statsDateNav').style.display = period === 'all' ? 'none' : 'flex';
  loadStatsData();
}

function changeStatsDate(delta) {
  if (currentStatsPeriod === 'day') statsDate.setDate(statsDate.getDate() + delta);
  else if (currentStatsPeriod === 'week') statsDate.setDate(statsDate.getDate() + delta * 7);
  else if (currentStatsPeriod === 'month') statsDate.setMonth(statsDate.getMonth() + delta);
  else if (currentStatsPeriod === 'year') statsDate.setFullYear(statsDate.getFullYear() + delta);
  loadStatsData();
}

// 计算当前期与上期范围
function getPeriodRanges() {
  const p = currentStatsPeriod;
  const y = statsDate.getFullYear(), m = statsDate.getMonth() + 1;

  if (p === 'day') {
    const d = new Date(statsDate); d.setDate(d.getDate() - 1);
    return {
      cur: { start: formatDate(statsDate), end: formatDate(statsDate), days: 1, label: `${m}月${statsDate.getDate()}日支出` },
      prev: { start: formatDate(d), end: formatDate(d) }
    };
  }
  if (p === 'week') {
    const mon = getWeekMonday(statsDate);
    const sun = new Date(mon); sun.setDate(mon.getDate() + 6);
    const pMon = new Date(mon); pMon.setDate(mon.getDate() - 7);
    const pSun = new Date(sun); pSun.setDate(sun.getDate() - 7);
    return {
      cur: { start: formatDate(mon), end: formatDate(sun), days: 7, label: '本周支出' },
      prev: { start: formatDate(pMon), end: formatDate(pSun) }
    };
  }
  if (p === 'month') {
    const days = new Date(y, m, 0).getDate();
    const pm = m === 1 ? 12 : m - 1, py = m === 1 ? y - 1 : y;
    return {
      cur: { start: `${y}-${String(m).padStart(2, '0')}-01`, end: `${y}-${String(m).padStart(2, '0')}-${days}`, days, label: `${y}年${m}月支出` },
      prev: { start: `${py}-${String(pm).padStart(2, '0')}-01`, end: `${py}-${String(pm).padStart(2, '0')}-${new Date(py, pm, 0).getDate()}` }
    };
  }
  if (p === 'year') {
    const py = y - 1;
    return {
      cur: { start: `${y}-01-01`, end: `${y}-12-31`, days: (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0 ? 366 : 365, label: `${y}年支出` },
      prev: { start: `${py}-01-01`, end: `${py}-12-31` }
    };
  }
  // 全部
  const all = getTransactions();
  if (!all.length) return { cur: { start: getTodayStr(), end: getTodayStr(), days: 1, label: '全部支出' }, prev: null };
  const dates = all.map(t => t.date).sort();
  const days = Math.max(1, Math.round((new Date(dates[dates.length - 1]) - new Date(dates[0])) / 86400000) + 1);
  return { cur: { start: dates[0], end: dates[dates.length - 1], days, label: '全部支出' }, prev: null };
}

function updateStatsDateDisplay(label) {
  const el = document.getElementById('statsDateDisplay');
  const p = currentStatsPeriod;
  if (p === 'day') {
    const v = formatDate(statsDate);
    el.textContent = v === getTodayStr() ? '今天' : `${statsDate.getMonth() + 1}月${statsDate.getDate()}日`;
  } else if (p === 'week') {
    const mon = getWeekMonday(statsDate);
    const sun = new Date(mon); sun.setDate(mon.getDate() + 6);
    el.textContent = `${mon.getMonth() + 1}.${mon.getDate()} — ${sun.getMonth() + 1}.${sun.getDate()}`;
  } else if (p === 'month') {
    el.textContent = `${statsDate.getFullYear()}年${statsDate.getMonth() + 1}月`;
  } else if (p === 'year') {
    el.textContent = `${statsDate.getFullYear()}年`;
  } else {
    el.textContent = label || '';
  }
}

function loadStatsData() {
  const { cur, prev } = getPeriodRanges();
  updateStatsDateDisplay();

  const allTx = getTransactionsByDateRange(cur.start, cur.end);
  const tx = allTx.filter(t => !isIncome(t));            // 支出
  const incomeTx = allTx.filter(isIncome);               // 收入
  const total = sumBy(tx, t => t.amount);
  const incomeTotal = sumBy(incomeTx, t => t.amount);

  // 概要（支出）
  document.getElementById('statsPeriodLabel').textContent = cur.label;
  document.getElementById('statsTotal').textContent = fmtMoney(total);
  document.getElementById('statsCount').textContent = tx.length;
  document.getElementById('statsAvg').textContent = '¥' + (tx.length ? Math.round(total / tx.length) : 0);
  document.getElementById('statsMax').textContent = '¥' + (tx.length ? Math.round(Math.max(...tx.map(t => t.amount))) : 0);
  document.getElementById('statsDailyAvg').textContent = '¥' + Math.round(total / cur.days);

  // 收入概览
  renderIncomePanel(incomeTx, incomeTotal, total);

  // 环比（支出）
  const chip = document.getElementById('statsCompare');
  if (prev) {
    const prevTotal = sumBy(getTransactionsByDateRange(prev.start, prev.end).filter(t => !isIncome(t)), t => t.amount);
    if (prevTotal === 0 && total === 0) { chip.hidden = true; }
    else if (prevTotal === 0) {
      chip.hidden = false; chip.className = 'compare-chip up'; chip.textContent = '▲ 较上期新增支出';
    } else {
      const pct = ((total - prevTotal) / prevTotal) * 100;
      chip.hidden = false;
      chip.className = 'compare-chip ' + (pct >= 0 ? 'up' : 'down');
      chip.textContent = `${pct >= 0 ? '▲' : '▼'} 较上期 ${Math.abs(pct).toFixed(1)}%`;
    }
  } else {
    chip.hidden = true;
  }

  drawDonut(tx);
  renderCategoryRank(tx, total);
  renderSubcatRank(tx);
  renderTimeDist(tx, total);
  drawTrend(tx);
  renderTypeDist(tx, total);
  renderTransactionList('statsTransactionList', allTx);
  document.getElementById('statsListCount').textContent = allTx.length ? `共 ${allTx.length} 笔` : '';

  // 日历
  const calDate = (currentStatsPeriod === 'month' || currentStatsPeriod === 'year') ? statsDate : new Date();
  calendarMonth = new Date(calDate.getFullYear(), calDate.getMonth(), 1);
  renderCalendar(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1);
}

// ---------- 收入概览 ----------
function renderIncomePanel(incomeTx, incomeTotal, expenseTotal) {
  const card = document.getElementById('incomeCard');
  if (!incomeTx.length) { card.hidden = true; return; }
  card.hidden = false;

  document.getElementById('incomeTotal').textContent = '¥' + fmtMoney(incomeTotal);
  document.getElementById('incomeCount').textContent = incomeTx.length;
  document.getElementById('incomeAvg').textContent = '¥' + Math.round(incomeTotal / incomeTx.length);
  document.getElementById('incomeMax').textContent = '¥' + Math.round(Math.max(...incomeTx.map(t => t.amount)));
  document.getElementById('incomeNet').textContent = '¥' + Math.round(incomeTotal - expenseTotal);

  // 收入构成排行
  const map = {};
  incomeTx.forEach(t => { map[t.category] = (map[t.category] || 0) + t.amount; });
  const entries = Object.entries(map).sort((a, b) => b[1] - a[1]);
  const max = entries[0][1];
  const el = document.getElementById('incomeRank');
  el.innerHTML = entries.map(([cat, amt]) => `
    <div class="hbar-row">
      <div class="hbar-top">
        <span class="h-name">${getCategoryIcon(cat)} ${cat}</span>
        <span class="h-val income-val">¥${fmtMoney(amt)}<small>${incomeTotal ? (amt / incomeTotal * 100).toFixed(0) : 0}%</small></span>
      </div>
      <div class="hbar-track"><i class="income-bar" style="width:${(amt / max * 100).toFixed(1)}%"></i></div>
    </div>`).join('');
}

// ---------- 甜甜圈 ----------
function drawDonut(tx) {
  const canvas = document.getElementById('pieChart');
  const wrap = document.querySelector('.donut-wrap');
  const dpr = window.devicePixelRatio || 1;
  const size = Math.min(wrap.clientWidth || 200, 200);
  canvas.width = size * dpr;
  canvas.height = size * dpr;
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, size, size);

  const catStats = calcCategoryStats(tx);
  const entries = Object.entries(catStats).sort((a, b) => b[1] - a[1]);
  const total = entries.reduce((s, e) => s + e[1], 0);

  // 图例
  const legend = document.getElementById('pieLegend');
  if (!total) {
    legend.innerHTML = '';
    ctx.fillStyle = '#A49C8B';
    ctx.font = '13px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('暂无数据', size / 2, size / 2);
    return;
  }

  const cx = size / 2, cy = size / 2;
  const r = size * 0.42;
  const gap = 0.03; // 弧间隙
  let angle = -Math.PI / 2;

  entries.forEach(([cat, amount], i) => {
    const slice = (amount / total) * Math.PI * 2;
    const a0 = angle + gap / 2, a1 = angle + slice - gap / 2;
    if (a1 > a0) {
      ctx.beginPath();
      ctx.arc(cx, cy, r, a0, a1);
      ctx.strokeStyle = catColor(cat);
      ctx.lineWidth = size * 0.1;
      ctx.lineCap = 'butt';
      ctx.stroke();
    }
    angle += slice;
  });

  // 中心文字
  ctx.fillStyle = '#26221A';
  ctx.font = `600 ${Math.round(size * 0.1)}px Georgia, serif`;
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText('¥' + Math.round(total), cx, cy - size * 0.035);
  ctx.fillStyle = '#A49C8B';
  ctx.font = `${Math.round(size * 0.058)}px sans-serif`;
  ctx.fillText(`${entries.length} 个分类`, cx, cy + size * 0.075);

  legend.innerHTML = entries.map(([cat, amount], i) => `
    <span class="legend-item">
      <span class="legend-dot" style="background:${catColor(cat)}"></span>
      ${cat} <b>¥${Math.round(amount)}</b>
    </span>`).join('');
}

// ---------- 分类排行 ----------
function renderCategoryRank(tx, total) {
  const el = document.getElementById('categoryRank');
  const catStats = calcCategoryStats(tx);
  const entries = Object.entries(catStats).sort((a, b) => b[1] - a[1]);
  if (!entries.length) { el.innerHTML = '<div class="empty-state">暂无数据</div>'; return; }
  const max = entries[0][1];

  el.innerHTML = entries.map(([cat, amount], i) => `
    <div class="rank-row">
      <span class="rank-no">${i + 1}</span>
      <div class="rank-main">
        <div class="rank-name"><span>${getCategoryIcon(cat)} ${cat}</span><span class="r-amt">¥${fmtMoney(amount)}</span></div>
        <div class="rank-bar"><i style="width:${(amount / max * 100).toFixed(1)}%;background:${catColor(cat)}"></i></div>
        <div class="rank-extra">${total ? (amount / total * 100).toFixed(1) : 0}% · 占比</div>
      </div>
    </div>`).join('');
}

// ---------- 子分类 TOP5 ----------
function renderSubcatRank(tx) {
  const el = document.getElementById('subcatRank');
  const map = {};
  tx.forEach(t => {
    const key = t.subcategory || t.category;
    if (!map[key]) map[key] = { amount: 0, count: 0, cat: t.category };
    map[key].amount += t.amount;
    map[key].count++;
  });
  const entries = Object.entries(map).sort((a, b) => b[1].amount - a[1].amount).slice(0, 5);
  if (!entries.length) { el.innerHTML = '<div class="empty-state">暂无数据</div>'; return; }
  const max = entries[0][1].amount;

  el.innerHTML = entries.map(([name, d], i) => `
    <div class="rank-row">
      <span class="rank-no">${i + 1}</span>
      <div class="rank-main">
        <div class="rank-name"><span>${name} <span class="muted">· ${d.cat}</span></span><span class="r-amt">¥${fmtMoney(d.amount)}</span></div>
        <div class="rank-bar"><i style="width:${(d.amount / max * 100).toFixed(1)}%"></i></div>
        <div class="rank-extra">${d.count} 笔</div>
      </div>
    </div>`).join('');
}

// ---------- 消费时段 ----------
function renderTimeDist(tx, total) {
  const el = document.getElementById('timeDist');
  const segs = TIME_SEGMENTS.map(s => ({ ...s, amount: 0, count: 0 }));
  tx.forEach(t => {
    const h = parseInt((t.time || '12:00').split(':')[0], 10) || 0;
    const seg = segs.find(s => h >= s.from && h < s.to);
    if (seg) { seg.amount += t.amount; seg.count++; }
  });
  const max = Math.max(...segs.map(s => s.amount));
  if (!total) { el.innerHTML = '<div class="empty-state">暂无数据</div>'; return; }

  el.innerHTML = segs.map(s => `
    <div class="hbar-row">
      <div class="hbar-top">
        <span class="h-name">${s.name}</span>
        <span class="h-val">¥${fmtMoney(s.amount)}<small>${s.count} 笔${total ? ' · ' + (s.amount / total * 100).toFixed(0) + '%' : ''}</small></span>
      </div>
      <div class="hbar-track"><i style="width:${max ? (s.amount / max * 100).toFixed(1) : 0}%"></i></div>
    </div>`).join('');
}

// ---------- 记录方式 ----------
function renderTypeDist(tx, total) {
  const el = document.getElementById('typeDist');
  const manual = tx.filter(t => t.type !== 'auto');
  const auto = tx.filter(t => t.type === 'auto');
  const mAmt = manual.reduce((s, t) => s + t.amount, 0);
  const aAmt = auto.reduce((s, t) => s + t.amount, 0);
  const max = Math.max(mAmt, aAmt);
  if (!tx.length) { el.innerHTML = '<div class="empty-state">暂无数据</div>'; return; }

  const row = (name, amt, count) => `
    <div class="hbar-row">
      <div class="hbar-top">
        <span class="h-name">${name}</span>
        <span class="h-val">¥${fmtMoney(amt)}<small>${count} 笔</small></span>
      </div>
      <div class="hbar-track"><i style="width:${max ? (amt / max * 100).toFixed(1) : 0}%"></i></div>
    </div>`;
  el.innerHTML = row('✍ 手动记账', mAmt, manual.length) + row('📷 拍照记账', aAmt, auto.length);
}

// ---------- 趋势图（自适应粒度）----------
function buildTrendData(tx) {
  const p = currentStatsPeriod;
  const daily = {};
  tx.forEach(t => { daily[t.date] = (daily[t.date] || 0) + t.amount; });

  if (p === 'day') {
    // 按小时聚合（每 2 小时一格）
    const slots = Array.from({ length: 12 }, (_, i) => ({ label: i * 2 + '时', value: 0 }));
    tx.forEach(t => {
      const h = parseInt((t.time || '12:00').split(':')[0], 10) || 0;
      slots[Math.floor(h / 2)].value += t.amount;
    });
    return { data: slots, unit: '按 2 小时' };
  }
  if (p === 'week') {
    const mon = getWeekMonday(statsDate);
    const days = [];
    for (let i = 0; i < 7; i++) {
      const d = new Date(mon); d.setDate(mon.getDate() + i);
      days.push({ label: WEEK_CN[d.getDay()], value: daily[formatDate(d)] || 0 });
    }
    return { data: days, unit: '按天' };
  }
  if (p === 'month') {
    const y = statsDate.getFullYear(), m = statsDate.getMonth() + 1;
    const daysInMonth = new Date(y, m, 0).getDate();
    const days = [];
    for (let d = 1; d <= daysInMonth; d++) {
      const key = `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      days.push({ label: String(d), value: daily[key] || 0 });
    }
    return { data: days, unit: '按天' };
  }
  if (p === 'year') {
    const y = statsDate.getFullYear();
    const months = [];
    for (let m = 1; m <= 12; m++) {
      const amt = tx.filter(t => t.date.startsWith(`${y}-${String(m).padStart(2, '0')}`)).reduce((s, t) => s + t.amount, 0);
      months.push({ label: m + '月', value: amt });
    }
    return { data: months, unit: '按月' };
  }
  // 全部：按月聚合
  const monthMap = {};
  tx.forEach(t => {
    const key = t.date.slice(0, 7);
    monthMap[key] = (monthMap[key] || 0) + t.amount;
  });
  let keys = Object.keys(monthMap).sort();
  if (keys.length > 24) keys = keys.slice(-24);
  return { data: keys.map(k => ({ label: parseInt(k.slice(5, 7)) + '月', value: monthMap[k] })), unit: '按月' };
}

function drawTrend(tx) {
  const { data, unit } = buildTrendData(tx);
  document.getElementById('trendUnit').textContent = unit;

  const canvas = document.getElementById('barChart');
  const wrap = document.querySelector('.chart-wrap');
  const dpr = window.devicePixelRatio || 1;
  const W = wrap.clientWidth || 320, H = 190;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, W, H);

  if (!tx.length) {
    ctx.fillStyle = '#A49C8B';
    ctx.font = '13px sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('暂无数据', W / 2, H / 2);
    return;
  }

  const maxVal = Math.max(...data.map(d => d.value)) || 1;
  const pad = { top: 14, bottom: 22, left: 4, right: 4 };
  const cw = W - pad.left - pad.right;
  const ch = H - pad.top - pad.bottom;
  const n = data.length;
  const barW = Math.min((cw - (n - 1) * 3) / n, 26);
  const gap = (cw - barW * n) / (n + 1);
  const labelStep = Math.ceil(n / 7);

  data.forEach((d, i) => {
    const x = pad.left + gap + i * (barW + gap);
    const h = d.value > 0 ? Math.max((d.value / maxVal) * ch, 2) : 0;
    const y = pad.top + ch - h;

    if (d.value > 0) {
      ctx.fillStyle = d.value === maxVal ? '#B93A21' : '#26221A';
      if (ctx.roundRect) {
        ctx.beginPath();
        ctx.roundRect(x, y, barW, h, [3, 3, 0, 0]);
        ctx.fill();
      } else {
        ctx.fillRect(x, y, barW, h);
      }
    }

    if (i % labelStep === 0 || i === n - 1) {
      ctx.fillStyle = '#A49C8B';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(d.label, x + barW / 2, H - 6);
    }
  });
}

// ---------- 日历 ----------
function renderCalendar(year, month) {
  document.getElementById('calendarMonthDisplay').textContent = `${year}年${month}月`;

  const grid = document.getElementById('calendarGrid');
  const weekdays = ['一', '二', '三', '四', '五', '六', '日'];
  const firstDay = new Date(year, month - 1, 1).getDay();
  const startCol = firstDay === 0 ? 6 : firstDay - 1;
  const daysInMonth = new Date(year, month, 0).getDate();
  const prevMonth = month === 1 ? 12 : month - 1;
  const prevYear = month === 1 ? year - 1 : year;
  const prevDays = new Date(prevYear, prevMonth, 0).getDate();
  const today = getTodayStr();

  const monthTx = getTransactionsByMonth(year, month).filter(t => !isIncome(t));
  const dailyMap = {};
  monthTx.forEach(t => { dailyMap[t.date] = (dailyMap[t.date] || 0) + t.amount; });

  let html = weekdays.map(w => `<div class="cal-week">${w}</div>`).join('');

  for (let i = prevDays - startCol + 1; i <= prevDays; i++) {
    html += `<div class="cal-day other"><span class="d-num">${i}</span></div>`;
  }
  for (let d = 1; d <= daysInMonth; d++) {
    const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    const amt = dailyMap[dateStr];
    html += `
      <div class="cal-day ${dateStr === today ? 'today' : ''}">
        <span class="d-num">${d}</span>
        ${amt ? `<span class="d-amt">${Math.round(amt)}</span>` : ''}
      </div>`;
  }
  const totalCells = startCol + daysInMonth;
  const remaining = (7 - (totalCells % 7)) % 7;
  for (let i = 1; i <= remaining; i++) {
    html += `<div class="cal-day other"><span class="d-num">${i}</span></div>`;
  }
  grid.innerHTML = html;
}

function changeCalendarMonth(delta) {
  calendarMonth.setMonth(calendarMonth.getMonth() + delta);
  renderCalendar(calendarMonth.getFullYear(), calendarMonth.getMonth() + 1);
  if (currentStatsPeriod === 'month' || currentStatsPeriod === 'year') {
    statsDate = new Date(calendarMonth);
    loadStatsData();
  }
}

// ============================================================
// 明细页
// ============================================================
function changeBillsMonth(delta) {
  billsMonth.setMonth(billsMonth.getMonth() + delta);
  renderBills();
}

function renderBills() {
  const y = billsMonth.getFullYear(), m = billsMonth.getMonth() + 1;
  document.getElementById('billsMonthDisplay').textContent = `${y}年${m}月`;

  const tx = getTransactionsByMonth(y, m)
    .sort((a, b) => (b.date + (b.time || '')).localeCompare(a.date + (a.time || '')));

  const expenseTotal = sumBy(tx.filter(t => !isIncome(t)), t => t.amount);
  const incomeTotal = sumBy(tx.filter(isIncome), t => t.amount);

  document.getElementById('billsCount').textContent = tx.length;
  document.getElementById('billsTotal').textContent = '¥' + fmtMoney(expenseTotal);
  const incomeEl = document.getElementById('billsIncome');
  if (incomeEl) {
    incomeEl.parentElement.style.display = incomeTotal > 0 ? '' : 'none';
    incomeEl.textContent = '¥' + fmtMoney(incomeTotal);
  }

  const list = document.getElementById('billsList');
  if (!tx.length) {
    list.innerHTML = '<div class="panel"><div class="empty-state">本月暂无账目</div></div>';
    return;
  }

  // 按日期分组
  const groups = {};
  tx.forEach(t => { (groups[t.date] = groups[t.date] || []).push(t); });

  list.innerHTML = Object.keys(groups).sort((a, b) => b.localeCompare(a)).map(date => {
    const items = groups[date];
    const dayExpense = sumBy(items.filter(t => !isIncome(t)), t => t.amount);
    const dayIncome = sumBy(items.filter(isIncome), t => t.amount);
    const d = new Date(date + 'T00:00:00');
    return `
      <div class="day-group">
        <div class="day-head">
          <span>${d.getMonth() + 1}月${d.getDate()}日 · 周${WEEK_CN[d.getDay()]}</span>
          <span class="d-amt">${dayIncome > 0 ? `<em class="income-val">+¥${fmtMoney(dayIncome)}</em> · ` : ''}¥${fmtMoney(dayExpense)}</span>
        </div>
        <div class="day-panel">
          ${items.map(t => `
            <div class="tx-row" onclick="deleteBill('${t.id}')" title="点击删除">
              <div class="tx-ico">${getCategoryIcon(t.category)}</div>
              <div class="tx-main">
                <div class="tx-title">${t.subcategory || t.category}${t.type === 'auto' ? ' <span class="muted">📷</span>' : ''}</div>
                <div class="tx-sub">${t.note || (t.items && t.items.length ? t.items.join('、') : t.category)}</div>
              </div>
              <div class="tx-right">
                <div class="tx-amount fig ${isIncome(t) ? 'income-val' : ''}">${isIncome(t) ? '+' : ''}¥${fmtMoney(t.amount)}</div>
                <div class="tx-time">${t.time || ''}</div>
              </div>
            </div>`).join('')}
        </div>
      </div>`;
  }).join('');
}

function deleteBill(id) {
  if (!confirm('删除这笔账目？')) return;
  deleteTransaction(id);
  renderBills();
  showToast('已删除');
}

// ============================================================
// 设置页
// ============================================================
function renderSettings() {
  const s = getApiSettings();
  document.getElementById('settingsApiUrl').value = s.url || '';
  document.getElementById('settingsApiKey').value = s.key || '';
  document.getElementById('settingsModel').value = s.model || '';
  document.getElementById('settingsPrompt').value = getOcrPrompt() || DEFAULT_OCR_PROMPT;
  renderCategorySettings();
}

function renderCategorySettings() {
  const el = document.getElementById('settingsCategories');
  el.innerHTML = getCategories().map((c, i) => `
    <div class="settings-cat">
      <span class="sc-ico">${c.icon}</span>
      <span class="sc-name">${c.name}</span>
      <span class="sc-sub">${c.subcategories.join('、') || '—'}</span>
      <button class="sc-del" onclick="removeCategory(${i})">✕</button>
    </div>`).join('');
}

function saveApiSettings() {
  saveApiSettingsToStorage({
    url: document.getElementById('settingsApiUrl').value.trim(),
    key: document.getElementById('settingsApiKey').value.trim(),
    model: document.getElementById('settingsModel').value.trim()
  });
  saveOcrPrompt(document.getElementById('settingsPrompt').value);
  showToast('配置已保存');
}

function addCategory() {
  const name = prompt('分类名称（如：宠物）');
  if (!name || !name.trim()) return;
  const icon = prompt('分类图标（如：🐱）') || '📌';
  const cats = getCategories();
  cats.push({ name: name.trim(), icon, subcategories: [] });
  saveCategories(cats);
  renderCategorySettings();
  showToast('已添加');
}

function removeCategory(index) {
  const cats = getCategories();
  if (cats.length <= 1) return showToast('至少保留一个分类');
  if (!confirm(`删除分类「${cats[index].name}」？`)) return;
  cats.splice(index, 1);
  saveCategories(cats);
  renderCategorySettings();
  showToast('已删除');
}

function clearAllData() {
  if (!confirm('确定清除全部账目？此操作不可恢复！')) return;
  clearAllTransactions();
  renderHome();
  renderBills();
  showToast('账目已清空');
}

// ============================================================
// 初始化
// ============================================================
function getWeekMonday(d) {
  const date = new Date(d);
  const day = date.getDay();
  date.setDate(date.getDate() - day + (day === 0 ? -6 : 1));
  return date;
}

document.addEventListener('DOMContentLoaded', () => {
  // 顶栏日期
  const now = new Date();
  document.getElementById('headerCaption').textContent =
    `${now.getMonth() + 1}月${now.getDate()}日 · 周${WEEK_CN[now.getDay()]}`;

  renderHome();
  initManualForm();
  renderBills();
  loadStatsData();

  // 窗口尺寸变化时重绘图表
  let resizeTimer;
  window.addEventListener('resize', () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() => {
      if (currentPage === 'stats') loadStatsData();
    }, 200);
  });
});
