// ===== Data Layer - localStorage =====

const STORAGE_KEY = 'jianji_transactions';

// 预设分类模板
const PRESET_CATEGORIES = [
  { name: '餐饮', icon: '🍽️', subcategories: ['早餐', '午餐', '晚餐', '外卖', '奶茶', '咖啡', '水果', '零食'] },
  { name: '交通', icon: '🚗', subcategories: ['公交', '地铁', '打车', '加油', '停车', '火车', '飞机'] },
  { name: '购物', icon: '🛍️', subcategories: ['超市', '服装', '电子产品', '日用品', '美妆', '家居'] },
  { name: '娱乐', icon: '🎮', subcategories: ['电影', '游戏', '健身', '旅游', 'KTV', '运动'] },
  { name: '居住', icon: '🏠', subcategories: ['房租', '水电', '物业', '维修', '网络', '燃气'] },
  { name: '医疗', icon: '💊', subcategories: ['看病', '买药', '体检', '牙科'] },
  { name: '教育', icon: '📚', subcategories: ['课程', '书籍', '文具', '培训'] },
  { name: '通讯', icon: '📱', subcategories: ['话费', '流量', '设备'] },
  { name: '其他', icon: '📌', subcategories: ['转账', '红包', '礼物', '其他'] }
];

// 预设收入分类
const PRESET_INCOME_CATEGORIES = [
  { name: '工资', icon: '💰', subcategories: [] },
  { name: '奖金', icon: '🏅', subcategories: [] },
  { name: '兼职', icon: '💼', subcategories: [] },
  { name: '理财', icon: '📈', subcategories: [] },
  { name: '红包', icon: '🧧', subcategories: [] },
  { name: '退款', icon: '↩️', subcategories: [] },
  { name: '其他收入', icon: '📌', subcategories: [] }
];

// ===== 获取所有分类 =====
function getCategories() {
  const saved = localStorage.getItem('jianji_categories');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {}
  }
  return PRESET_CATEGORIES;
}

// ===== 保存分类 =====
function saveCategories(categories) {
  localStorage.setItem('jianji_categories', JSON.stringify(categories));
}

// ===== 获取收入分类 =====
function getIncomeCategories() {
  const saved = localStorage.getItem('jianji_income_categories');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {}
  }
  return PRESET_INCOME_CATEGORIES;
}

// ===== 保存收入分类 =====
function saveIncomeCategories(categories) {
  localStorage.setItem('jianji_income_categories', JSON.stringify(categories));
}

// ===== 获取所有交易记录 =====
function getTransactions() {
  const data = localStorage.getItem(STORAGE_KEY);
  if (!data) return [];
  try {
    return JSON.parse(data);
  } catch (e) {
    return [];
  }
}

// ===== 保存交易记录 =====
function saveTransactions(transactions) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(transactions));
}

// ===== 添加一条记录 =====
function addTransaction(record) {
  const transactions = getTransactions();
  const newRecord = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
    amount: parseFloat(record.amount),
    category: record.category || '其他',
    subcategory: record.subcategory || '',
    note: record.note || '',
    date: record.date,
    time: record.time,
    type: record.type || 'manual',
    flow: record.flow === 'income' ? 'income' : 'expense',
    platform: record.platform || '',
    items: record.items || [],
    createdAt: Date.now()
  };
  transactions.unshift(newRecord);
  saveTransactions(transactions);
  return newRecord;
}

// ===== 删除一条记录 =====
function deleteTransaction(id) {
  let transactions = getTransactions();
  transactions = transactions.filter(t => t.id !== id);
  saveTransactions(transactions);
}

// ===== 按日期范围查询 =====
function getTransactionsByDateRange(startDate, endDate) {
  const transactions = getTransactions();
  return transactions.filter(t => {
    return t.date >= startDate && t.date <= endDate;
  });
}

// ===== 按日期查询 =====
function getTransactionsByDate(date) {
  return getTransactionsByDateRange(date, date);
}

// ===== 按月查询 =====
function getTransactionsByMonth(year, month) {
  const start = `${year}-${String(month).padStart(2, '0')}-01`;
  const lastDay = new Date(year, month, 0).getDate();
  const end = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
  return getTransactionsByDateRange(start, end);
}

// ===== 按周查询 =====
function getTransactionsByWeek(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1); // 周一为开始
  const monday = new Date(d.setDate(diff));
  const sunday = new Date(monday);
  sunday.setDate(monday.getDate() + 6);
  
  const start = formatDate(monday);
  const end = formatDate(sunday);
  return getTransactionsByDateRange(start, end);
}

// ===== 统计 =====
function calcStats(transactions) {
  const total = transactions.reduce((sum, t) => sum + t.amount, 0);
  const count = transactions.length;
  return { total, count };
}

// ===== 按分类统计 =====
function calcCategoryStats(transactions) {
  const map = {};
  transactions.forEach(t => {
    const cat = t.category || '其他';
    if (!map[cat]) map[cat] = 0;
    map[cat] += t.amount;
  });
  return map;
}

// ===== 工具函数 =====
function formatDate(d) {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function getTodayStr() {
  return formatDate(new Date());
}

function getTimeStr() {
  const d = new Date();
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

function getMonthDays(year, month) {
  return new Date(year, month, 0).getDate();
}

function getFirstDayOfMonth(year, month) {
  return new Date(year, month - 1, 1).getDay();
}

// ===== API 设置 =====
function getApiSettings() {
  const saved = localStorage.getItem('jianji_api_settings_v2');
  if (saved) {
    try {
      return JSON.parse(saved);
    } catch (e) {}
  }
  return {
    url: 'https://open.bigmodel.cn/api/paas/v4/chat/completions',
    key: '51bcfc59b56847f683fd572744174923.O2o5N17YaaINNKf8',
    model: 'glm-4.6v'
  };
}

function saveApiSettingsToStorage(settings) {
  localStorage.setItem('jianji_api_settings_v2', JSON.stringify(settings));
}

function getOcrPrompt() {
  return localStorage.getItem('jianji_ocr_prompt_v2') || '';
}

function saveOcrPrompt(prompt) {
  localStorage.setItem('jianji_ocr_prompt_v2', prompt);
}

// ===== 导出数据 =====
function exportData() {
  const data = {
    transactions: getTransactions(),
    categories: getCategories(),
    exportTime: new Date().toISOString()
  };
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `简记数据_${getTodayStr()}.json`;
  a.click();
  URL.revokeObjectURL(url);
}

// ===== 清除所有交易数据 =====
function clearAllTransactions() {
  localStorage.removeItem(STORAGE_KEY);
}